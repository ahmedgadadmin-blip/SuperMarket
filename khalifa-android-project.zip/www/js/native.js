/* سوبر ماركت الخليفة — التخزين (SQLite مشفّرة) + القفل (بصمة / رقم سري) + النسخ الاحتياطي المشفّر */
'use strict';
(function () {
  const P = window.NativePlugins || null;
  const NATIVE = !!(P && P.isNative);
  const COLS = ['products', 'invoices', 'wallets', 'moves', 'expenses', 'customers', 'suppliers'];
  const DBN = 'khalifa';
  const LS_DB = 'khalifa_db_v1', LS_META = 'khalifa_meta_v1';
  const te = new TextEncoder(), td = new TextDecoder();

  /* ---------- أدوات ---------- */
  const rnd = n => crypto.getRandomValues(new Uint8Array(n));
  const hex = u => [...u].map(b => b.toString(16).padStart(2, '0')).join('');
  function b64(u) { let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); }
  const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
  function ctEq(a, b) { if (a.length !== b.length) return false; let d = 0; for (let i = 0; i < a.length; i++) d |= a[i] ^ b[i]; return d === 0; }
  async function pbkdf2(pass, salt, iter) {
    const k = await crypto.subtle.importKey('raw', te.encode(pass), 'PBKDF2', false, ['deriveBits']);
    return new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: iter }, k, 256));
  }
  async function aesKey(pass, salt, iter) {
    return crypto.subtle.importKey('raw', await pbkdf2(pass, salt, iter), 'AES-GCM', false, ['encrypt', 'decrypt']);
  }
  async function encryptText(text, pass) {
    const salt = rnd(16), iv = rnd(12), iter = 200000;
    const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await aesKey(pass, salt, iter), te.encode(text));
    return JSON.stringify({ app: 'khalifa', v: 1, enc: 'AES-256-GCM', kdf: 'PBKDF2-SHA256', iter, salt: b64(salt), iv: b64(iv), data: b64(new Uint8Array(ct)) });
  }
  async function decryptText(o, pass) {
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(o.iv) }, await aesKey(pass, unb64(o.salt), o.iter || 200000), unb64(o.data));
    return td.decode(pt);
  }

  /* ---------- التخزين ---------- */
  const meta = {};
  let conn = null, snap = new Map(), ords = new Map(), ordSeq = 0, chain = Promise.resolve();

  async function persist(db) {
    const next = new Map(), set = [];
    for (const c of COLS) {
      const arr = c === 'invoices' ? [...db[c]].reverse() : db[c];   // الفواتير: الأحدث أولاً في الذاكرة
      for (const r of arr) {
        const k = c + '\0' + r.id; let o = ords.get(k); if (o == null) o = ++ordSeq;
        next.set(k, [JSON.stringify(r), o, c, r.id]);
      }
    }
    for (const [k, [js, o, c, id]] of next)
      if (snap.get(k) !== js || ords.get(k) !== o)
        set.push({ statement: 'INSERT OR REPLACE INTO records(coll,id,ord,data) VALUES (?,?,?,?)', values: [c, id, o, js] });
    for (const k of snap.keys()) if (!next.has(k)) { const [c, id] = k.split('\0'); set.push({ statement: 'DELETE FROM records WHERE coll=? AND id=?', values: [c, id] }); }
    const m = { seq: String(db.seq || 0), settings: JSON.stringify(db.settings || {}), ordSeq: String(ordSeq) };
    for (const k in m) { meta[k] = m[k]; set.push({ statement: 'INSERT OR REPLACE INTO meta(k,v) VALUES (?,?)', values: [k, m[k]] }); }
    await conn.executeSet(set, true);
    snap = new Map([...next].map(([k, v]) => [k, v[0]]));
    ords = new Map([...next].map(([k, v]) => [k, v[1]]));
  }

  const Store = {
    native: NATIVE,
    async init() {
      if (!NATIVE) { try { Object.assign(meta, JSON.parse(localStorage.getItem(LS_META) || '{}')); } catch (e) { } return; }
      const sqlite = new P.SQLiteConnection(P.CapacitorSQLite);
      if (!(await sqlite.isSecretStored()).result) await sqlite.setEncryptionSecret(hex(rnd(32)));  // مفتاح التشفير يُحفظ في Android Keystore
      const ok = (await sqlite.checkConnectionsConsistency()).result;
      const has = (await sqlite.isConnection(DBN, false)).result;
      conn = (ok && has) ? await sqlite.retrieveConnection(DBN, false) : await sqlite.createConnection(DBN, true, 'secret', 1, false);
      await conn.open();
      await conn.execute('CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT);' +
        'CREATE TABLE IF NOT EXISTS records(coll TEXT NOT NULL, id TEXT NOT NULL, ord INTEGER NOT NULL, data TEXT NOT NULL, PRIMARY KEY(coll,id));');
      const r = await conn.query('SELECT k,v FROM meta');
      (r.values || []).forEach(x => { meta[x.k] = x.v; });
    },
    getMeta: (k, d) => (k in meta ? meta[k] : d),
    async setMeta(k, v) {
      meta[k] = String(v);
      if (NATIVE) await conn.run('INSERT OR REPLACE INTO meta(k,v) VALUES (?,?)', [k, String(v)]);
      else localStorage.setItem(LS_META, JSON.stringify(meta));
    },
    async load() {
      if (!NATIVE) { try { return JSON.parse(localStorage.getItem(LS_DB)); } catch (e) { return null; } }
      if (!meta.settings) return null;                         // أول تشغيل
      const r = await conn.query('SELECT coll,id,ord,data FROM records ORDER BY ord ASC');
      const d = { seq: +meta.seq || 0, settings: JSON.parse(meta.settings) };
      COLS.forEach(c => { d[c] = []; });
      ordSeq = +meta.ordSeq || 0;
      for (const x of (r.values || [])) {
        if (!d[x.coll]) continue;
        d[x.coll].push(JSON.parse(x.data)); const k = x.coll + '\0' + x.id; snap.set(k, x.data); ords.set(k, x.ord);
      }
      d.invoices.reverse();
      return d;
    },
    save(db) {
      if (!NATIVE) { try { localStorage.setItem(LS_DB, JSON.stringify(db)); } catch (e) { } return Promise.resolve(); }
      chain = chain.then(() => persist(db)).catch(e => console.error('save failed', e));
      return chain;
    },
    normalize(d) {
      COLS.forEach(c => { if (!Array.isArray(d[c])) d[c] = []; });
      d.settings = d.settings || { store: 'سوبر ماركت الخليفة', phone: '', lang: 'ar' };
      d.seq = +d.seq || 0; return d;
    },
    /* نسخة احتياطية مشفّرة بكلمة سر */
    async exportBackup(db, filename) {
      const pass = prompt('اكتب كلمة سر لحماية النسخة الاحتياطية (4 أحرف على الأقل). ستحتاجها عند الاستعادة.');
      if (!pass || pass.length < 4) { toast('تم الإلغاء — كلمة السر مطلوبة'); return; }
      const text = await encryptText(JSON.stringify(db), pass);
      if (NATIVE) {
        const { Filesystem, Directory, Encoding, Share } = P;
        await Filesystem.writeFile({ path: filename, data: text, directory: Directory.Cache, encoding: Encoding.UTF8 });
        const { uri } = await Filesystem.getUri({ path: filename, directory: Directory.Cache });
        await Share.share({ title: 'نسخة احتياطية', url: uri, dialogTitle: 'احفظ النسخة الاحتياطية' });
      } else {
        const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' })); a.download = filename; a.click();
      }
      toast('تم تصدير النسخة المشفّرة ✓');
    },
    async parseBackup(text) {
      const o = JSON.parse(text);
      if (o && o.enc) {
        const pass = prompt('اكتب كلمة سر النسخة الاحتياطية');
        if (!pass) throw new Error('cancel');
        return JSON.parse(await decryptText(o, pass));
      }
      return o;   // نسخة قديمة غير مشفّرة
    }
  };

  /* ---------- شاشة الرقم السري ---------- */
  function pinPad(o) {
    return new Promise(res => {
      const el = document.createElement('div'); el.className = 'lock';
      el.innerHTML = `<div class="lock-in"><img src="assets/icon.png" class="lock-logo" alt="">
        <h2>${o.title}</h2><p class="lsub">${o.sub || ''}</p>
        <div class="dots">${'<i></i>'.repeat(6)}</div><div class="lmsg"></div>
        <div class="pad">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => `<button data-k="${n}">${n}</button>`).join('')}
          <button class="alt" data-k="bio" ${o.bio ? '' : 'style="visibility:hidden"'}>🖐️</button>
          <button data-k="0">0</button><button class="alt" data-k="del">⌫</button></div>
        ${o.cancel ? `<button class="lcancel">${o.cancel}</button>` : ''}</div>`;
      document.body.appendChild(el);
      const dots = el.querySelectorAll('.dots i'), msg = el.querySelector('.lmsg');
      let pin = '', busy = false;
      const upd = () => dots.forEach((d, i) => d.classList.toggle('on', i < pin.length));
      const finish = v => { el.remove(); res(v); };
      async function submit() {
        busy = true;
        const err = o.check ? await o.check(pin) : null;
        if (err) { msg.textContent = err; el.classList.add('shake'); setTimeout(() => el.classList.remove('shake'), 400); pin = ''; upd(); busy = false; return; }
        finish({ pin });
      }
      async function tryBio() {
        if (!o.bio || busy) return; busy = true; msg.textContent = '';
        if (await Sec.bioAuth('افتح التطبيق ببصمتك')) { finish({ bio: true }); return; }
        busy = false;
      }
      el.querySelectorAll('.pad button').forEach(b => b.onclick = () => {
        const k = b.dataset.k; if (busy) return;
        if (k === 'bio') return tryBio();
        if (k === 'del') pin = pin.slice(0, -1);
        else if (pin.length < 6) pin += k;
        upd(); msg.textContent = '';
        if (pin.length === 6) submit();
      });
      const c = el.querySelector('.lcancel'); if (c) c.onclick = () => finish(null);
      if (o.bio && o.autoBio) setTimeout(tryBio, 300);
    });
  }

  /* ---------- القفل ---------- */
  const Sec = {
    locked: false, busy: false, started: false,
    hasPin: () => !!Store.getMeta('pin_hash'),
    bioOn: () => Store.getMeta('bio') === '1',
    autoLock: () => +Store.getMeta('autolock', '15'),
    async bioAvailable() { if (!NATIVE) return false; try { return !!(await P.BiometricAuth.checkBiometry()).isAvailable; } catch (e) { return false; } },
    async bioAuth(reason) {
      if (!NATIVE) return false; Sec.busy = true;
      try {
        await P.BiometricAuth.authenticate({ reason, cancelTitle: 'استخدم الرقم السري', allowDeviceCredential: false, androidTitle: 'سوبر ماركت الخليفة', androidSubtitle: reason, androidConfirmationRequired: false });
        return true;
      } catch (e) { return false; } finally { setTimeout(() => { Sec.busy = false; }, 800); }
    },
    async setPin(pin) {
      const salt = rnd(16);
      await Store.setMeta('pin_salt', b64(salt)); await Store.setMeta('pin_hash', b64(await pbkdf2(pin, salt, 150000)));
      await Store.setMeta('fails', '0'); await Store.setMeta('lock_until', '0');
    },
    /* يرجع نص الخطأ أو null عند النجاح */
    async checkPin(pin) {
      const wait = Math.ceil((+Store.getMeta('lock_until', '0') - Date.now()) / 1000);
      if (wait > 0) return `محاولات كثيرة — انتظر ${wait} ثانية`;
      const ok = ctEq(await pbkdf2(pin, unb64(Store.getMeta('pin_salt')), 150000), unb64(Store.getMeta('pin_hash')));
      if (ok) { await Store.setMeta('fails', '0'); return null; }
      const f = (+Store.getMeta('fails', '0')) + 1; await Store.setMeta('fails', f);
      if (f >= 5) { const s = Math.min(900, 30 * 2 ** (f - 5)); await Store.setMeta('lock_until', Date.now() + s * 1000); return `رقم خاطئ — تم القفل ${s} ثانية`; }
      return `الرقم السري غير صحيح (متبقي ${5 - f} محاولات)`;
    },
    async newPin(cancellable) {
      for (; ;) {
        const a = await pinPad({ title: 'إنشاء رقم سري', sub: 'اختر 6 أرقام لحماية متجرك', cancel: cancellable ? 'إلغاء' : '' });
        if (!a) return false;
        const b = await pinPad({ title: 'أكّد الرقم السري', cancel: 'رجوع', check: p => (p === a.pin ? null : 'الرقمان غير متطابقين') });
        if (b) { await Sec.setPin(a.pin); return true; }
      }
    },
    async setup() {
      await Sec.newPin(false);
      if (await Sec.bioAvailable() && confirm('تفعيل فتح التطبيق بالبصمة؟')) {
        if (await Sec.bioAuth('تأكيد البصمة')) await Store.setMeta('bio', '1');
      }
    },
    async unlock() {
      if (!Sec.hasPin()) return Sec.setup();
      await pinPad({ title: 'أدخل الرقم السري', sub: 'سوبر ماركت الخليفة', bio: Sec.bioOn() && await Sec.bioAvailable(), autoBio: true, check: Sec.checkPin });
    },
    async lock() { if (Sec.locked || !Sec.started) return; Sec.locked = true; try { await Sec.unlock(); } finally { Sec.locked = false; } },
    async confirmPin(why) {
      const r = await pinPad({ title: 'تأكيد بالرقم السري', sub: why || '', cancel: 'إلغاء', bio: Sec.bioOn() && await Sec.bioAvailable(), check: Sec.checkPin });
      return !!r;
    },
    async changePin() { if (await Sec.confirmPin('تغيير الرقم السري')) { if (await Sec.newPin(true)) toast('تم تغيير الرقم السري ✓'); } },
    async toggleBio() {
      if (Sec.bioOn()) { if (await Sec.confirmPin('إيقاف البصمة')) { await Store.setMeta('bio', '0'); toast('تم إيقاف البصمة'); render(); } return; }
      if (!(await Sec.bioAvailable())) return toast('البصمة غير متاحة — سجّل بصمة في إعدادات الهاتف أولاً');
      if (await Sec.bioAuth('تأكيد البصمة')) { await Store.setMeta('bio', '1'); toast('تم تفعيل البصمة ✓'); render(); }
    },
    async setAutoLock(v) { await Store.setMeta('autolock', v); toast('تم الحفظ ✓'); },
    card() {
      const al = String(Sec.autoLock());
      return `<div class="card"><b>🔒 الأمان</b>
        <button class="btn" onclick="Sec.changePin()">تغيير الرقم السري</button>
        <button class="btn blue" onclick="Sec.toggleBio()">${Sec.bioOn() ? 'إيقاف القفل بالبصمة' : 'تفعيل القفل بالبصمة'}</button>
        <label>القفل التلقائي بعد الخروج من التطبيق</label>
        <select onchange="Sec.setAutoLock(this.value)">${[['0', 'فوراً'], ['15', '15 ثانية'], ['60', 'دقيقة'], ['300', '5 دقائق']].map(([v, t]) => `<option value="${v}" ${al === v ? 'selected' : ''}>${t}</option>`).join('')}</select>
        <p style="color:#6b7a70;font-size:13px;margin:8px 0 0">${NATIVE ? 'بياناتك مشفّرة (SQLCipher) على الجهاز، والتطبيق يمنع لقطات الشاشة.' : 'وضع المتصفح: البيانات غير مشفّرة. التشفير الكامل في تطبيق الأندرويد.'}<br>⚠️ لا توجد طريقة لاسترجاع الرقم السري — احتفظ بنسخة احتياطية.</p></div>`;
    }
  };

  /* القفل التلقائي عند مغادرة التطبيق */
  let hiddenAt = 0;
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { hiddenAt = (Sec.locked || Sec.busy) ? 0 : Date.now(); return; }
    if (hiddenAt && Date.now() - hiddenAt >= Sec.autoLock() * 1000) Sec.lock();
    hiddenAt = 0;
  });

  /* زر الرجوع في أندرويد */
  if (NATIVE && P.App) {
    P.App.addListener('backButton', () => {
      if (Sec.locked || document.querySelector('.lock')) return;
      if (document.querySelector('.modal')) return closeModal();
      if (typeof stack !== 'undefined' && stack.length) return back();
      P.App.exitApp();
    });
  }

  window.Store = Store; window.Sec = Sec;
})();
