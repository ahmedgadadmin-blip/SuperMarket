/* سوبر ماركت الخليفة - تطبيق إدارة المتجر (يعمل بدون إنترنت، البيانات في المتصفح) */
'use strict';
const $ = s => document.querySelector(s);
const fmt = n => (Math.round((+n || 0) * 100) / 100).toLocaleString('en-US') + ' ج.م';
const num = n => (Math.round((+n || 0) * 100) / 100).toLocaleString('en-US');
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const pad = n => String(n).padStart(2, '0');
const now = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const today = () => now().slice(0, 10);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/* ---------- البيانات ---------- */
function seed() {
  return {
    products: [
      { id: uid(), name: 'مياه معدنية كبيرة', emoji: '💧', price: 10, cost: 7, stock: 50, cat: 'مشروبات' },
      { id: uid(), name: 'شاي العروسة', emoji: '🍵', price: 25, cost: 20, stock: 32, cat: 'بقالة' },
      { id: uid(), name: 'زيت كريستال', emoji: '🛢️', price: 120, cost: 105, stock: 18, cat: 'بقالة' },
      { id: uid(), name: 'سكر 1 كجم', emoji: '🍚', price: 30, cost: 25, stock: 24, cat: 'بقالة' },
      { id: uid(), name: 'لبن جهينة', emoji: '🥛', price: 18, cost: 14, stock: 40, cat: 'ألبان' },
    ],
    invoices: [], wallets: [
      { id: uid(), name: 'فودافون كاش', number: '01012345678', balance: 2450, color: '#e60000', icon: '📱' },
      { id: uid(), name: 'أورانج كاش', number: '01234567890', balance: 1230, color: '#f08a1c', icon: '📱' },
      { id: uid(), name: 'اتصالات كاش', number: '01123456789', balance: 980, color: '#2aa04a', icon: '📱' },
      { id: uid(), name: 'بنك مصر', number: '345678901234', balance: 450, color: '#b57a1c', icon: '🏦' },
    ], moves: [], expenses: [], customers: [], suppliers: [],
    seq: 127, settings: { store: 'سوبر ماركت الخليفة', phone: '01012345678', lang: 'ar' }
  };
}
let db = seed();
const save = () => Store.save(db);

let cart = [], stack = [], current = 'home', cat = 'الكل', q = '';

/* ---------- أدوات الواجهة ---------- */
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 1800); }
function modal(html) { const m = document.createElement('div'); m.className = 'modal'; m.innerHTML = `<div class="sheet">${html}</div>`; m.onclick = e => { if (e.target === m) m.remove(); }; $('#app').appendChild(m); return m; }
function closeModal() { document.querySelectorAll('.modal').forEach(m => m.remove()); }
function go(name, arg, push) {
  if (push) stack.push([current, window._arg]);
  else if (['home', 'wallets', 'inventory', 'sales', 'more'].includes(name)) stack = [];
  current = name; window._arg = arg; render();
}
function back() { const p = stack.pop(); if (p) { current = p[0]; window._arg = p[1]; render(); } else go('home'); }

const todayInvoices = () => db.invoices.filter(i => i.date.slice(0, 10) === today());
const profitOf = i => i.items.reduce((s, x) => s + (x.price - (x.cost || 0)) * x.qty, 0) - (i.discount || 0);

/* ---------- الشاشات ---------- */
const screens = {
  home() {
    const t = todayInvoices(), sales = t.reduce((s, i) => s + i.net, 0), prof = t.reduce((s, i) => s + profitOf(i), 0);
    const exp = db.expenses.filter(e => e.date.slice(0, 10) === today() && e.type === 'out').reduce((s, e) => s + e.amount, 0);
    const low = db.products.filter(p => p.stock <= 10).length;
    const cust = db.customers.reduce((s, c) => s + c.debt, 0), sup = db.suppliers.reduce((s, c) => s + c.debt, 0);
    const cash = db.wallets.reduce((s, w) => s + w.balance, 0) + db.expenses.reduce((s, e) => s + (e.type === 'in' ? e.amount : -e.amount), 0) + db.invoices.filter(i => i.pay === 'نقدي').reduce((s, i) => s + i.net, 0);
    const l = db.invoices[0];
    return `<div class="grid g2">
      <div class="tile t-green"><small>مبيعات اليوم</small><b>${fmt(sales)}</b></div>
      <div class="tile t-green"><small>أرباح اليوم</small><b>${fmt(prof)}</b></div>
      <div class="tile t-red"><small>المصروفات</small><b>${fmt(exp)}</b></div>
      <div class="tile t-blue"><small>فواتير اليوم</small><b>${t.length}</b></div></div>
      <div class="grid g3" style="margin-top:10px">
      <div class="tile t-orange" onclick="go('inventory')"><small>منتجات نفدت</small><b>${low}</b></div>
      <div class="tile t-purple" onclick="go('customers',0,1)"><small>ديون العملاء</small><b>${num(cust)}</b></div>
      <div class="tile t-teal"><small>رصيد الخزنة</small><b>${num(cash)}</b></div></div>
      <div class="card last"><div><small>آخر فاتورة</small><br><b>#${l ? l.no : '—'}</b><br><small>${l ? l.date : ''}</small></div>
      ${l ? `<button class="pill" onclick="go('invoice','${l.id}',1)">عرض التفاصيل</button>` : ''}</div>
      <button class="btn" onclick="go('sales')">🛒 فاتورة جديدة</button>`;
  },

  sales() {
    const cats = ['الكل', ...new Set(db.products.map(p => p.cat))];
    const list = db.products.filter(p => (cat === 'الكل' || p.cat === cat) && p.name.includes(q));
    const cnt = cart.reduce((s, x) => s + x.qty, 0), tot = cart.reduce((s, x) => s + x.qty * x.price, 0);
    return `<input class="search" placeholder="ابحث عن منتج..." value="${esc(q)}" oninput="q=this.value;renderKeep(this)">
      <div class="chips">${cats.map(c => `<button class="chip ${c === cat ? 'on' : ''}" onclick="cat='${c}';render()">${c}</button>`).join('')}</div>
      ${list.map(p => `<div class="prod"><button class="add" onclick="addCart('${p.id}')">+</button>
        <div class="inf"><b>${esc(p.name)}</b><small>سعر البيع: ${num(p.price)} ج.م</small></div>
        <span class="stk ${p.stock <= 10 ? 'low' : ''}">المخزون: ${p.stock}</span><div class="em">${p.emoji}</div></div>`).join('') || '<p style="text-align:center;color:#999;padding:30px">لا توجد منتجات</p>'}
      <div class="card sum" style="margin-top:14px"><span>${num(tot)} ج.م :الإجمالي</span><span>${cnt} :عدد الأصناف</span></div>
      <button class="btn" onclick="go('newInvoice',0,1)">🛒 إتمام الفاتورة</button>`;
  },

  newInvoice() {
    const tot = cart.reduce((s, x) => s + x.qty * x.price, 0);
    const disc = window._disc || 0, net = Math.max(0, tot - disc);
    return `<div class="card" style="margin-top:0">
      <label>طريقة الدفع</label><select id="pay"><option>نقدي</option>${db.wallets.map(w => `<option>${esc(w.name)}</option>`).join('')}<option>آجل</option></select>
      <label>اسم العميل (اختياري)</label><input id="cust" placeholder="أدخل اسم العميل"></div>
      <div class="card"><table><tr><th></th><th>الإجمالي</th><th>السعر</th><th>الكمية</th><th>المنتج</th></tr>
      ${cart.map((x, i) => `<tr><td><button class="del" onclick="cart.splice(${i},1);render()">🗑</button></td><td>${num(x.qty * x.price)}</td><td>${num(x.price)}</td>
        <td><button class="chip" onclick="qty(${i},-1)">−</button> ${x.qty} <button class="chip" onclick="qty(${i},1)">+</button></td><td>${esc(x.name)}</td></tr>`).join('') || '<tr><td colspan="5" style="color:#999;padding:20px">الفاتورة فارغة</td></tr>'}</table></div>
      <div class="card"><div class="sum"><span>${num(tot)} ج.م</span><span>المجموع الفرعي</span></div>
      <div class="sum"><span><input type="number" style="width:90px;padding:4px" value="${disc}" onchange="window._disc=+this.value;render()"></span><span>خصم</span></div>
      <div class="sum tot"><span>${num(net)} ج.م</span><span>الإجمالي</span></div></div>
      <div class="row"><button class="btn sec" onclick="cart=[];window._disc=0;back()">إلغاء</button><button class="btn" onclick="saveInvoice()">حفظ الفاتورة</button></div>`;
  },

  inventory() {
    const cats = ['الكل', ...new Set(db.products.map(p => p.cat))];
    const list = db.products.filter(p => (cat === 'الكل' || p.cat === cat) && p.name.includes(q));
    return `<input class="search" placeholder="ابحث عن منتج..." value="${esc(q)}" oninput="q=this.value;renderKeep(this)">
      <div class="chips">${cats.map(c => `<button class="chip ${c === cat ? 'on' : ''}" onclick="cat='${c}';render()">${c}</button>`).join('')}</div>
      <button class="btn sec" style="margin:0 0 10px" onclick="productForm()">＋ إضافة منتج</button>
      ${list.map(p => `<div class="prod"><button class="edit" onclick="productForm('${p.id}')">✎</button>
        <div class="inf"><b>${esc(p.name)}</b><small>سعر البيع: ${num(p.price)} ج.م — التكلفة: ${num(p.cost)}</small><br><small class="stk ${p.stock <= 10 ? 'low' : ''}">المخزون: ${p.stock}</small></div><div class="em">${p.emoji}</div></div>`).join('')}`;
  },

  invoices() {
    const list = db.invoices.filter(i => String(i.no).includes(q) || (i.customer || '').includes(q));
    return `<input class="search" placeholder="ابحث برقم الفاتورة أو اسم العميل..." value="${esc(q)}" oninput="q=this.value;renderKeep(this)">
      ${list.map(i => `<div class="inv"><button class="btn sm" onclick="go('invoice','${i.id}',1)">عرض</button>
        <div class="a"><b>#${i.no}</b><small>${i.date} — ${esc(i.pay)}</small></div><div class="am">${num(i.net)} ج.م</div></div>`).join('') || '<p style="text-align:center;color:#999;padding:30px">لا توجد فواتير بعد</p>'}`;
  },

  invoice(id) {
    const i = db.invoices.find(x => x.id === id); if (!i) return 'غير موجودة';
    return `<div class="paper"><div class="head"><b style="font-size:18px">${esc(db.settings.store)}</b><br><small>${esc(db.settings.phone)}</small><br>
      <b>فاتورة #${i.no}</b><br><small>كود: ${esc(i.code)} — ${i.date}</small></div>
      <table><tr><th>الإجمالي</th><th>السعر</th><th>الكمية</th><th>المنتج</th></tr>
      ${i.items.map(x => `<tr><td>${num(x.qty * x.price)}</td><td>${num(x.price)}</td><td>${x.qty}</td><td>${esc(x.name)}</td></tr>`).join('')}</table>
      <div class="sum"><span>${num(i.total)}</span><span>المجموع الفرعي</span></div><div class="sum"><span>${num(i.discount)}</span><span>الخصم</span></div>
      <div class="sum tot"><span>${num(i.net)} ج.م</span><span>الإجمالي</span></div>
      <div class="sum"><span>${esc(i.pay)}</span><span>طريقة الدفع</span></div>${i.customer ? `<div class="sum"><span>${esc(i.customer)}</span><span>العميل</span></div>` : ''}</div>
      <div class="row"><button class="btn danger" onclick="delInvoice('${i.id}')">حذف</button><button class="btn blue" onclick="shareInvoice('${i.id}')">مشاركة</button><button class="btn" onclick="printInvoice('${i.id}')">طباعة</button></div>`;
  },

  wallets() {
    const tab = window._wtab || 'wallets';
    const tabs = `<div class="tabs"><button class="${tab === 'moves' ? 'on' : ''}" onclick="window._wtab='moves';render()">الحركات</button><button class="${tab === 'wallets' ? 'on' : ''}" onclick="window._wtab='wallets';render()">المحافظ</button></div>`;
    if (tab === 'moves') return tabs + (db.moves.slice().reverse().map(m => { const w = db.wallets.find(x => x.id === m.wid); return `<div class="wal"><div class="am" style="color:${m.type === 'in' ? '#127a39' : '#e5421f'}">${m.type === 'in' ? '+' : '−'}${num(m.amount)}</div><div class="a"><b>${esc(w ? w.name : '')}</b><small>${m.date} ${esc(m.note)}</small></div></div>`; }).join('') || '<p style="text-align:center;color:#999;padding:30px">لا توجد حركات</p>');
    return tabs + db.wallets.map(w => `<div class="wal" onclick="walletMove('${w.id}')"><div class="am">${num(w.balance)} ج.م</div>
      <div class="a"><b>${esc(w.name)}</b><small>${esc(w.number)}</small></div><div class="ic" style="background:${w.color}">${w.icon}</div></div>`).join('') +
      `<button class="btn" onclick="walletForm()">＋ إضافة محفظة</button>`;
  },

  treasury() {
    const tab = window._ttab || 'exp';
    const list = db.expenses.slice().reverse();
    const out = db.expenses.filter(e => e.type === 'out').reduce((s, e) => s + e.amount, 0), inn = db.expenses.filter(e => e.type === 'in').reduce((s, e) => s + e.amount, 0);
    return `<div class="grid g2"><div class="tile t-red"><small>إجمالي المصروفات</small><b>${fmt(out)}</b></div><div class="tile t-green"><small>إجمالي الدخل</small><b>${fmt(inn)}</b></div></div>
      <button class="btn" onclick="expenseForm()">＋ تسجيل حركة جديدة</button>
      <h3 class="sec">الحركات</h3>${list.map(e => `<div class="wal"><div class="am" style="color:${e.type === 'in' ? '#127a39' : '#e5421f'}">${e.type === 'in' ? '+' : '−'}${num(e.amount)}</div><div class="a"><b>${esc(e.category)}</b><small>${e.date} ${esc(e.note)}</small></div></div>`).join('') || '<p style="text-align:center;color:#999;padding:20px">لا توجد حركات</p>'}`;
  },

  reports() {
    const from = window._from || today().slice(0, 8) + '01', to = window._to || today();
    const inv = db.invoices.filter(i => i.date.slice(0, 10) >= from && i.date.slice(0, 10) <= to);
    const sales = inv.reduce((s, i) => s + i.net, 0), prof = inv.reduce((s, i) => s + profitOf(i), 0);
    const exp = db.expenses.filter(e => e.type === 'out' && e.date.slice(0, 10) >= from && e.date.slice(0, 10) <= to).reduce((s, e) => s + e.amount, 0);
    const days = {}; inv.forEach(i => { const d = i.date.slice(5, 10); days[d] = (days[d] || 0) + i.net; });
    const keys = Object.keys(days).sort().slice(-10), mx = Math.max(1, ...keys.map(k => days[k]));
    return `<div class="row"><div><label>من</label><input type="date" value="${from}" onchange="window._from=this.value;render()"></div><div><label>إلى</label><input type="date" value="${to}" onchange="window._to=this.value;render()"></div></div>
      <div class="grid g2" style="margin-top:12px"><div class="tile t-green"><small>إجمالي المبيعات</small><b>${fmt(sales)}</b></div><div class="tile t-blue"><small>صافي الربح</small><b>${fmt(prof - exp)}</b></div>
      <div class="tile t-red"><small>المصروفات</small><b>${fmt(exp)}</b></div><div class="tile t-orange"><small>عدد الفواتير</small><b>${inv.length}</b></div>
      <div class="tile t-red"><small>ديون العملاء</small><b>${fmt(db.customers.reduce((s, c) => s + c.debt, 0))}</b></div><div class="tile t-blue"><small>ديون الموردين</small><b>${fmt(db.suppliers.reduce((s, c) => s + c.debt, 0))}</b></div></div>
      <h3 class="sec">المبيعات خلال الفترة</h3><div class="card"><div class="bar" style="margin-bottom:20px">${keys.map(k => `<div style="height:${days[k] / mx * 100}%"><span>${k}</span></div>`).join('') || '<p style="color:#999;margin:auto">لا توجد بيانات</p>'}</div></div>`;
  },

  parties(kind) {
    const arr = db[kind], title = kind === 'customers' ? 'عميل' : 'مورد';
    return `<button class="btn" style="margin:0 0 10px" onclick="partyForm('${kind}')">＋ إضافة ${title}</button>` +
      arr.map(c => `<div class="wal"><div class="am" style="color:#e5421f">${num(c.debt)} ج.م</div><div class="a"><b>${esc(c.name)}</b><small>${title}</small></div><button class="btn sm" onclick="partyPay('${kind}','${c.id}')">سداد</button></div>`).join('') || '';
  },
  customers() { return screens.parties('customers'); },
  suppliers() { return screens.parties('suppliers'); },

  more() {
    return `<div class="menu">
      <button onclick="go('invoices',0,1)"><span>🧾 الفواتير</span><span>‹</span></button>
      <button onclick="go('treasury',0,1)"><span>💰 الخزنة والمصروفات</span><span>‹</span></button>
      <button onclick="go('reports',0,1)"><span>📊 التقارير</span><span>‹</span></button>
      <button onclick="go('customers',0,1)"><span>👥 العملاء</span><span>‹</span></button>
      <button onclick="go('suppliers',0,1)"><span>🚚 الموردون</span><span>‹</span></button>
      <button onclick="go('backup',0,1)"><span>☁️ النسخ الاحتياطي</span><span>‹</span></button>
      <button onclick="go('settings',0,1)"><span>⚙️ الإعدادات</span><span>‹</span></button></div>`;
  },

  backup() {
    return `<button class="btn" style="padding:22px" onclick="exportBackup()">⬇️ تصدير نسخة احتياطية<br><small>حفظ البيانات بصيغة JSON</small></button>
      <button class="btn blue" style="padding:22px" onclick="$('#file').click()">⬆️ استعادة نسخة احتياطية<br><small>اختر ملف النسخة</small></button>
      <input type="file" id="file" accept="*/*" class="hidden" onchange="importBackup(this)">
      <div class="card"><b>البيانات المشمولة</b><br><br>✅ المنتجات<br>✅ المبيعات والفواتير<br>✅ المحافظ وحركاتها<br>✅ الخزنة والمصروفات<br>✅ العملاء والموردون</div>
      <p style="text-align:center;color:#6b7a70;font-size:13px;margin-top:10px">يتم حفظ النسخة داخل جهازك. احتفظ بها في مكان آمن.</p>`;
  },

  settings() {
    const s = db.settings;
    return `<div class="card" style="margin-top:0"><label>اسم المتجر</label><input id="st" value="${esc(s.store)}"><label>رقم الهاتف</label><input id="sp" value="${esc(s.phone)}">
      <button class="btn" onclick="db.settings.store=$('#st').value;db.settings.phone=$('#sp').value;save();toast('تم الحفظ ✓')">حفظ</button></div>
      <div class="card"><b>تصفير البيانات</b><p style="color:#6b7a70;font-size:13px;margin:6px 0">يحذف كل البيانات ويعيد البيانات التجريبية.</p>
      <button class="btn danger" onclick="if(confirm('هل أنت متأكد؟ سيتم حذف كل شيء')){Sec.confirmPin('حذف كل البيانات').then(ok=>{if(ok){db=seed();save();toast('تمت إعادة الضبط');go('home')}})}">حذف كل البيانات</button></div>
      ${Sec.card()}`;
  }
};

const titles = { home: 'لوحة التحكم', sales: 'المبيعات', newInvoice: 'فاتورة جديدة', inventory: 'إدارة المخزون', invoices: 'الفواتير', invoice: 'تفاصيل الفاتورة', wallets: 'المحافظ الإلكترونية', treasury: 'الخزنة والمصروفات', reports: 'التقارير', customers: 'العملاء', suppliers: 'الموردون', more: 'المزيد', backup: 'النسخ الاحتياطي', settings: 'الإعدادات' };
const navMap = { home: 'home', wallets: 'wallets', inventory: 'inventory', sales: 'sales', more: 'more' };

function render() {
  $('#title').textContent = titles[current] || '';
  $('#backBtn').classList.toggle('hidden', !stack.length);
  document.querySelectorAll('.nav button').forEach(b => b.classList.toggle('on', b.dataset.go === (navMap[current] || (stack[0] && navMap[stack[0][0]]) || 'more')));
  $('#view').innerHTML = screens[current](window._arg);
  $('#view').scrollTop = 0;
}
function renderKeep(el) { const p = el.selectionStart; const sc = $('#view').scrollTop; render(); $('#view').scrollTop = sc; const n = $('.search'); if (n) { n.focus(); n.setSelectionRange(p, p); } }

/* ---------- العمليات ---------- */
function addCart(id) {
  const p = db.products.find(x => x.id === id), c = cart.find(x => x.pid === id);
  if (c) { if (c.qty >= p.stock) return toast('لا يوجد مخزون كافٍ'); c.qty++; }
  else { if (p.stock < 1) return toast('نفد المخزون'); cart.push({ pid: id, name: p.name, price: p.price, cost: p.cost, qty: 1 }); }
  toast('تمت الإضافة ✓'); render();
}
function qty(i, d) { const x = cart[i], p = db.products.find(p => p.id === x.pid); const n = x.qty + d; if (n < 1) return; if (n > p.stock) return toast('لا يوجد مخزون كافٍ'); x.qty = n; render(); }
function saveInvoice() {
  if (!cart.length) return toast('الفاتورة فارغة');
  const total = cart.reduce((s, x) => s + x.qty * x.price, 0), discount = window._disc || 0, net = Math.max(0, total - discount);
  const pay = $('#pay').value, customer = $('#cust').value.trim();
  db.seq++;
  const inv = { id: uid(), no: String(db.seq).padStart(6, '0'), date: now(), pay, customer, items: cart.map(x => ({ ...x })), total, discount, net, code: uid().slice(0, 4).toUpperCase() + '-' + uid().slice(0, 4).toUpperCase() };
  cart.forEach(x => { const p = db.products.find(p => p.id === x.pid); if (p) p.stock -= x.qty; });
  const w = db.wallets.find(w => w.name === pay);
  if (w) { w.balance += net; db.moves.push({ id: uid(), wid: w.id, type: 'in', amount: net, note: 'فاتورة #' + inv.no, date: now() }); }
  if (pay === 'آجل' && customer) { let c = db.customers.find(c => c.name === customer); if (!c) { c = { id: uid(), name: customer, debt: 0 }; db.customers.push(c); } c.debt += net; }
  db.invoices.unshift(inv); save(); cart = []; window._disc = 0;
  toast('تم حفظ الفاتورة ✓'); stack = []; current = 'invoice'; window._arg = inv.id; stack.push(['home']); render();
}
function delInvoice(id) {
  if (!confirm('حذف الفاتورة وإرجاع المخزون؟')) return;
  const i = db.invoices.find(x => x.id === id);
  i.items.forEach(x => { const p = db.products.find(p => p.id === x.pid); if (p) p.stock += x.qty; });
  db.invoices = db.invoices.filter(x => x.id !== id); save(); toast('تم الحذف'); back();
}
function shareInvoice(id) {
  const i = db.invoices.find(x => x.id === id);
  const t = `${db.settings.store}\nفاتورة #${i.no} - ${i.date}\n` + i.items.map(x => `${x.name} × ${x.qty} = ${num(x.qty * x.price)}`).join('\n') + `\nالإجمالي: ${num(i.net)} ج.م`;
  if (navigator.share) navigator.share({ text: t }).catch(() => { }); else window.open('https://wa.me/?text=' + encodeURIComponent(t));
}
function productForm(id) {
  const p = id ? db.products.find(x => x.id === id) : { name: '', emoji: '📦', price: '', cost: '', stock: '', cat: 'بقالة' };
  modal(`<h3>${id ? 'تعديل منتج' : 'إضافة منتج'}</h3><label>الاسم</label><input id="f1" value="${esc(p.name)}"><div class="row"><div><label>سعر البيع</label><input id="f2" type="number" value="${p.price}"></div><div><label>سعر التكلفة</label><input id="f3" type="number" value="${p.cost}"></div></div>
    <div class="row"><div><label>الكمية</label><input id="f4" type="number" value="${p.stock}"></div><div><label>التصنيف</label><input id="f5" value="${esc(p.cat)}"></div></div><label>رمز تعبيري</label><input id="f6" value="${p.emoji}">
    <button class="btn" onclick="saveProduct('${id || ''}')">حفظ</button>${id ? `<button class="btn danger" onclick="if(confirm('حذف المنتج؟')){db.products=db.products.filter(x=>x.id!=='${id}');save();closeModal();render()}">حذف المنتج</button>` : ''}`);
}
function saveProduct(id) {
  const o = { name: $('#f1').value.trim(), price: +$('#f2').value, cost: +$('#f3').value, stock: +$('#f4').value, cat: $('#f5').value.trim() || 'عام', emoji: $('#f6').value || '📦' };
  if (!o.name) return toast('اكتب الاسم');
  if (id) Object.assign(db.products.find(x => x.id === id), o); else db.products.push({ id: uid(), ...o });
  save(); closeModal(); render(); toast('تم الحفظ ✓');
}
function walletForm() {
  modal(`<h3>إضافة محفظة</h3><label>الاسم</label><input id="f1"><label>الرقم</label><input id="f2"><label>الرصيد الافتتاحي</label><input id="f3" type="number" value="0"><button class="btn" onclick="db.wallets.push({id:uid(),name:$('#f1').value,number:$('#f2').value,balance:+$('#f3').value,color:'#127a39',icon:'📱'});save();closeModal();render()">حفظ</button>`);
}
function walletMove(id) {
  const w = db.wallets.find(x => x.id === id);
  modal(`<h3>${esc(w.name)} — رصيد ${fmt(w.balance)}</h3><label>نوع الحركة</label><select id="f1"><option value="in">إيداع</option><option value="out">سحب</option></select><label>المبلغ</label><input id="f2" type="number"><label>ملاحظة</label><input id="f3">
    <button class="btn" onclick="const a=+$('#f2').value;if(!a)return toast('اكتب المبلغ');const t=$('#f1').value;w=db.wallets.find(x=>x.id==='${id}');w.balance+=t==='in'?a:-a;db.moves.push({id:uid(),wid:w.id,type:t,amount:a,note:$('#f3').value,date:now()});save();closeModal();render();toast('تم ✓')">تسجيل حركة</button>`);
}
function expenseForm() {
  modal(`<h3>حركة جديدة</h3><label>النوع</label><select id="f1"><option value="out">مصروف</option><option value="in">دخل</option></select><label>التصنيف</label><select id="f2"><option>كهرباء</option><option>إيجار</option><option>رواتب</option><option>مشتريات</option><option>أخرى</option></select><label>المبلغ</label><input id="f3" type="number"><label>ملاحظة</label><input id="f4">
    <button class="btn" onclick="const a=+$('#f3').value;if(!a)return toast('اكتب المبلغ');db.expenses.push({id:uid(),type:$('#f1').value,category:$('#f2').value,amount:a,note:$('#f4').value,date:now()});save();closeModal();render();toast('تم ✓')">حفظ</button>`);
}
function partyForm(kind) { modal(`<h3>إضافة</h3><label>الاسم</label><input id="f1"><label>المديونية الحالية</label><input id="f2" type="number" value="0"><button class="btn" onclick="db['${kind}'].push({id:uid(),name:$('#f1').value,debt:+$('#f2').value});save();closeModal();render()">حفظ</button>`); }
function partyPay(kind, id) { const c = db[kind].find(x => x.id === id); const a = +prompt('المبلغ المسدد (المتبقي ' + c.debt + ')'); if (a > 0) { c.debt = Math.max(0, c.debt - a); save(); render(); toast('تم السداد ✓'); } }
function exportBackup() { Store.exportBackup(db, 'khalifa-backup-' + today() + '.json'); }
function importBackup(el) {
  const f = el.files[0]; if (!f) return; const r = new FileReader();
  r.onload = async () => {
    try {
      const d = await Store.parseBackup(r.result); if (!d || !d.products) throw 0;
      if (!(await Sec.confirmPin('استعادة النسخة ستستبدل كل البيانات الحالية'))) return;
      db = Store.normalize(d); save(); toast('تمت الاستعادة ✓'); go('home');
    } catch (e) { toast('ملف غير صالح أو كلمة سر خاطئة'); }
    el.value = '';
  };
  r.readAsText(f);
}
function printInvoice(id) { if (Store.native) shareInvoice(id); else window.print(); }

/* ---------- التشغيل ---------- */
function enterApp() {
  Sec.started = true; $('#splash').remove();
  ['#topbar', '#view', '#nav'].forEach(x => $(x).classList.remove('hidden')); render();
}
(async () => {
  try {
    await Store.init();
    const d = await Store.load();
    db = d ? Store.normalize(d) : seed(); save();
    await Sec.unlock();
    enterApp();
  } catch (e) {
    console.error(e);
    $('#splash').insertAdjacentHTML('beforeend', '<p style="color:#ffd">تعذّر فتح قاعدة البيانات. أعد تشغيل التطبيق.</p>');
  }
})();
$('#backBtn').onclick = back;
document.querySelectorAll('.nav button').forEach(b => b.onclick = () => { q = ''; cat = 'الكل'; go(b.dataset.go); });
