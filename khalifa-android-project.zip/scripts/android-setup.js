/* يُشغَّل بعد `npx cap add android`: أيقونة + شاشة بداية + حماية (FLAG_SECURE, منع النسخ الاحتياطي) */
const fs = require('fs'), path = require('path');
const sharp = require('sharp');

const GREEN = '#0a3a19';
const LOGO = path.join(__dirname, '..', 'assets-src', 'logo-1024.png');   // شعار العميل (مربع بحواف دائرية وخلفية شفافة)
const DENS = { mdpi: [48, 108], hdpi: [72, 162], xhdpi: [96, 216], xxhdpi: [144, 324], xxxhdpi: [192, 432] };

async function onCanvas(size, scale, bg) {          // الشعار في منتصف لوحة بحجم size
  const s = Math.round(size * scale);
  const logo = await sharp(LOGO).resize(s, s).png().toBuffer();
  return sharp({ create: { width: size, height: size, channels: 4, background: bg } })
    .composite([{ input: logo, left: Math.round((size - s) / 2), top: Math.round((size - s) / 2) }]).png().toBuffer();
}

async function writeIcons(resDir) {
  for (const [d, [legacy, adaptive]] of Object.entries(DENS)) {
    const dir = path.join(resDir, 'mipmap-' + d); fs.mkdirSync(dir, { recursive: true });
    for (const f of fs.readdirSync(dir)) if (/^ic_launcher.*\.webp$/.test(f)) fs.unlinkSync(path.join(dir, f));
    await sharp(LOGO).resize(legacy, legacy).png().toFile(path.join(dir, 'ic_launcher.png'));
    // الأيقونة الدائرية: الشعار على دائرة خضراء
    const c = legacy, circle = Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="${c}" height="${c}"><circle cx="${c / 2}" cy="${c / 2}" r="${c / 2}" fill="#fff"/></svg>`);
    await sharp(await onCanvas(c, 0.86, GREEN)).composite([{ input: circle, blend: 'dest-in' }]).png().toFile(path.join(dir, 'ic_launcher_round.png'));
    // Adaptive: الشعار داخل المنطقة الآمنة (66%) فوق خلفية خضراء
    await sharp(await onCanvas(adaptive, 0.66, { r: 0, g: 0, b: 0, alpha: 0 })).toFile(path.join(dir, 'ic_launcher_foreground.png'));
  }
  const vals = path.join(resDir, 'values'); fs.mkdirSync(vals, { recursive: true });
  fs.writeFileSync(path.join(vals, 'ic_launcher_background.xml'), `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">${GREEN}</color>\n</resources>\n`);
}

async function writeSplash(resDir) {
  const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
  for (const f of walk(resDir).filter(f => /[\\/]drawable[^\\/]*[\\/]splash\.png$/.test(f))) {
    const { width: w, height: h } = await sharp(f).metadata(); const s = Math.round(Math.min(w, h) * 0.46);
    const icon = await sharp(LOGO).resize(s, s).png().toBuffer();
    await sharp({ create: { width: w, height: h, channels: 3, background: GREEN } })
      .composite([{ input: icon, left: Math.round((w - s) / 2), top: Math.round((h - s) / 2) }]).png().toFile(f + '.tmp');
    fs.renameSync(f + '.tmp', f);
  }
}

function patchAndroid(root) {
  const app = path.join(root, 'app', 'src', 'main');
  // 1) AndroidManifest: لا نسخ احتياطي سحابي ولا http
  const mf = path.join(app, 'AndroidManifest.xml'); let m = fs.readFileSync(mf, 'utf8');
  m = m.replace(/android:allowBackup="[^"]*"/, 'android:allowBackup="false"');
  if (!/usesCleartextTraffic/.test(m)) m = m.replace('<application', '<application\n        android:usesCleartextTraffic="false"');
  if (!/fullBackupContent/.test(m)) m = m.replace('<application', '<application\n        android:fullBackupContent="false"');
  fs.writeFileSync(mf, m);
  // 2) MainActivity: FLAG_SECURE يمنع لقطات الشاشة ومعاينة التطبيقات الأخيرة
  const pkg = /package="([^"]+)"/.exec(m);
  const javaRoot = path.join(app, 'java'); let act = null;
  (function f(d) { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) f(p); else if (e.name === 'MainActivity.java') act = p; } })(javaRoot);
  if (!act) throw new Error('MainActivity.java not found');
  const pk = /^package\s+([\w.]+);/m.exec(fs.readFileSync(act, 'utf8'))[1];
  fs.writeFileSync(act, `package ${pk};

import android.os.Bundle;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        super.onCreate(savedInstanceState);
    }
}
`);
  // 3) الثيم: تعطيل edge-to-edge الإجباري حتى لا تختفي الواجهة تحت شريط الحالة
  const st = path.join(app, 'res', 'values', 'styles.xml');
  if (fs.existsSync(st)) {
    let s = fs.readFileSync(st, 'utf8');
    if (!/windowOptOutEdgeToEdgeEnforcement/.test(s))
      s = s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/, '$1\n        <item name="android:windowOptOutEdgeToEdgeEnforcement">true</item>');
    fs.writeFileSync(st, s);
  }
}

(async () => {
  const a = process.argv.slice(2);
  if (a[0] === '--icons-only') { await writeIcons(path.resolve(a[1] || 'preview')); console.log('icons written'); return; }
  const root = path.resolve('android'); if (!fs.existsSync(root)) throw new Error('شغّل npx cap add android أولاً');
  const res = path.join(root, 'app', 'src', 'main', 'res');
  await writeIcons(res); await writeSplash(res); patchAndroid(root);
  console.log('android project patched ✓');
})().catch(e => { console.error(e); process.exit(1); });
