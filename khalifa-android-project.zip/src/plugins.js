// يُجمَّع هذا الملف بواسطة esbuild إلى www/js/plugins.bundle.js ويكشف الإضافات للتطبيق
import { Capacitor } from '@capacitor/core';
import { CapacitorSQLite, SQLiteConnection } from '@capacitor-community/sqlite';
import { BiometricAuth } from '@aparajita/capacitor-biometric-auth';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { App } from '@capacitor/app';

window.NativePlugins = {
  isNative: Capacitor.isNativePlatform(),
  CapacitorSQLite, SQLiteConnection, BiometricAuth,
  Filesystem, Directory, Encoding, Share, App
};
